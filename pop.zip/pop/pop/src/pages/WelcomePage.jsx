import React from 'react';
import { useNavigate } from 'react-router-dom';

const WelcomePage = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 text-center p-4">
      {}
      <img
        src="/vite.svg" 
        alt="Logo"
        className="w-24 h-24 mb-6"
      />

      {}
      <h1 className="text-2xl font-bold mb-2">Welcome to PopX</h1>

      {}
      <p className="text-gray-600 mb-8">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
      </p>

      {}
      <button
        onClick={() => navigate('/signup')}
        className="w-full max-w-xs bg-purple-600 text-white py-2 rounded-md mb-4 hover:bg-purple-700 transition"
      >
        Create Account
      </button>

      {}
      <button
        onClick={() => navigate('/login')}
        className="w-full max-w-xs bg-gray-300 text-gray-700 py-2 rounded-md hover:bg-gray-400 transition"
      >
        Already Registered? Sign In
      </button>
    </div>
  );
};

export default WelcomePage;